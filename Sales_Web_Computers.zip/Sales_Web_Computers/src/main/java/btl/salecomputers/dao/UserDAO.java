package btl.salecomputers.dao;


import btl.salecomputers.entity.User;

public interface UserDAO {
	public void saveUser(User user);
}
