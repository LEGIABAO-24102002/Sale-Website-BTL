package btl.salecomputers.dao;

import java.util.List;

import btl.salecomputers.entity.ThuongHieu;

public interface ThuongHieuDAO {

	public List<ThuongHieu> getThuongHieus();
}
