package btl.salecomputers.dao;

import btl.salecomputers.entity.Authenticate;

public interface AuthenticateDAO {
	public void saveAu(Authenticate au);
}
