package btl.salecomputers.service;

import java.util.List;

import btl.salecomputers.entity.ThuongHieu;

public interface ThuongHieuService {
	public List<ThuongHieu> getThuongHieus();
}
