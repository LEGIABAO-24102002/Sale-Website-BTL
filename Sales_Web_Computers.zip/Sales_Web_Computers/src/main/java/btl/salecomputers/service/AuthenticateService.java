package btl.salecomputers.service;

import btl.salecomputers.entity.Authenticate;

public interface AuthenticateService {
	public void saveAu(Authenticate au);
}
